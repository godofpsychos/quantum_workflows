from qiskit_ibm_runtime import QiskitRuntimeService
import logging

qtoken = "a116fcaf286b09b2dd433838fda02904201f6bdee74395093bde0fcdc04a4040f72cd37c844e2d431ebad9b2fd2cc7e43a28e68e9af7d7d87322a85151435bfb"
id="csaynf5d8m00008z99e0"
service = QiskitRuntimeService(channel="ibm_quantum", token=qtoken)

print("We are before job load:")
completedJob = service.job(job_id=id)
print("We are after job")
print(completedJob.status())
